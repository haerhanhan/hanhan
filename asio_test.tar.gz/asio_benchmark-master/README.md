# asio_benchmark
  
Usage: asio_test client <host> <port> <threads> <blocksize> <sessions> <time>
  
Usage: asio_test server <address> <port> <threads> <blocksize>
  





client2/server2 是任意长度的echo client/server。

